import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Native shell config for the iOS / Android store builds.
 * The web app is unchanged — Capacitor only wraps the built client output.
 */
const config: CapacitorConfig = {
  appId: "app.lovable.talabatbetak",
  appName: "طلبات بيتك",
  // Static client output produced by `bun run build`.
  webDir: ".output/public",
  android: {
    allowMixedContent: false,
  },
  ios: {
    contentInset: "always",
  },
  plugins: {
    SplashScreen: {
      launchAutoHide: false,
      backgroundColor: "#fbf9f1",
      androidScaleType: "CENTER_CROP",
      showSpinner: false,
    },
    StatusBar: {
      style: "LIGHT",
      backgroundColor: "#ffd502",
      overlaysWebView: false,
    },
  },
};

export default config;
