# Responsive polish + store-ready packaging (UI only)

Make every screen behave correctly from 320px phones up to desktop, then add the app-store packaging layer (PWA metadata + Capacitor scaffold for iOS/Android builds). No business logic changes.

## 1. Responsive foundation

- Root head: keep `width=device-width, initial-scale=1`, add `viewport-fit=cover` so notch/safe-area insets work, plus `theme-color`.
- Global safe-area handling: pad fixed top bars with `env(safe-area-inset-top)` and bottom tab bars with `env(safe-area-inset-bottom)` via a small utility in `src/styles.css`.
- Mobile shell (`MobileShell`): full-width below `sm`, centered 480px frame only on larger screens; bottom nav sized to safe area; content bottom padding matched so the last row is never hidden.
- Dashboard shell (`DashboardShell`): sidebar collapses to the existing horizontal tab strip below `lg`; header row switches to the grid pattern (`grid-cols-[minmax(0,1fr)_auto]` + `min-w-0` + `truncate`) so long Arabic titles and action buttons never clip.
- Touch targets: minimum 44px height for buttons, chips, nav items, and table row actions.
- Kill horizontal page scroll: audit `min-w-[...]`, fixed widths, and long unbroken text across all route files; add `min-w-0` / `overflow-x-auto` where needed.

## 2. Tables: mixed approach

- Dense financial/log tables (payments, audit logs, settlements, commissions) keep horizontal scroll, with a scroll affordance (edge fade + sticky first column) so context stays visible.
- Primary operational tables (orders, restaurants, drivers, staff, menu, customers) get a card layout below `md`: each row renders as a stacked card with label/value pairs and its action buttons, while the table markup stays for `md+`. Implemented once in the shared `Table` primitive so all routes pick it up consistently.

## 3. Store-ready UI requirements

- Splash + icon set: generated app icon (192/512 maskable), `apple-touch-icon`, favicon, and Android/iOS splash source image.
- `public/manifest.webmanifest`: app name (طلبات بيتك), short name, `display: standalone`, `dir: rtl`, `lang: ar`, theme/background colors from the design tokens, icon entries; linked from the root head along with `apple-mobile-web-app-*` tags.
- Status-bar-friendly headers so the app looks correct in standalone mode (no browser chrome overlap).
- Back-navigation affordance on every non-root screen (Android hardware back parity).

## 4. Capacitor scaffold

- Add `@capacitor/core` + `@capacitor/cli` and `capacitor.config.ts` (appId `app.lovable.talabatbetak`, appName طلبات بيتك, webDir pointing at the built client output, splash/status-bar plugin config).
- Add npm scripts for `cap add ios` / `cap add android` / `cap sync`, plus a short `MOBILE.md` with the exact local steps to produce store builds (Xcode / Android Studio, signing, screenshots sizes required by both stores).
- Native platform folders are generated locally by the user (they require Xcode/Android SDK), not committed here — the scaffold and instructions make that one command.

## 5. Verification

- Playwright sweep of representative screens for each role at 320, 375, 414, 768, 1024, 1440 widths; assert no horizontal overflow and capture screenshots.
- Fix anything the sweep flags, then re-run.

## Technical notes

- All changes stay in `src/components/tb/shell.tsx`, `src/styles.css`, `src/routes/__root.tsx`, route files' layout classes, `public/`, and the new Capacitor config. Mock data and flow logic untouched.
