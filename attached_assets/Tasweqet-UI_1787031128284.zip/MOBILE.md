# Store builds (App Store + Google Play)

The web app stays a normal Lovable app; Capacitor only wraps the built client
output in a native shell. Native projects (`ios/`, `android/`) are generated on
your machine because they need Xcode / Android Studio.

## One-time setup

```bash
bun install
bun run build            # produces the static client output in .output/public
bunx cap add android     # needs Android Studio + JDK 17
bunx cap add ios         # needs macOS + Xcode
```

## Every time you change the app

```bash
bun run build
bunx cap sync
bunx cap open android    # or: bunx cap open ios
```

## App identity

- App ID: `app.lovable.talabatbetak`
- App name: طلبات بيتك
- Theme color `#ffd502`, background `#fbf9f1`
- Icon source: `public/icons/icon-1024.png` (1024×1024, no transparency)
  - Android: Image Asset Studio → adaptive icon (foreground = `icon-maskable-512.png`, background `#ffd502`)
  - iOS: drop `icon-1024.png` into `Assets.xcassets/AppIcon`

## Store asset checklist

Google Play
- App icon 512×512 PNG
- Feature graphic 1024×500
- Phone screenshots: at least 2, 1080×1920 (portrait)
- 7" and 10" tablet screenshots recommended
- Short description ≤80 chars, full description ≤4000 chars
- Privacy policy URL, data safety form, content rating, signed AAB (`Build > Generate Signed Bundle`)

App Store
- App icon 1024×1024 (no alpha, no rounded corners)
- iPhone 6.7" screenshots 1290×2796 and 6.5" 1242×2688
- iPad 12.9" screenshots 2048×2732 if iPad is supported
- Privacy policy URL, App Privacy answers, age rating
- Archive & upload via Xcode → App Store Connect

## UI requirements already handled in the app

- `viewport-fit=cover` plus safe-area padding on every top bar and bottom tab bar
  (notch / Dynamic Island / Android gesture bar)
- Minimum 44px touch targets on coarse pointers
- No horizontal page scroll from 320px upwards; wide dashboard tables either
  stack into cards or scroll with a sticky first column
- RTL Arabic document (`<html lang="ar" dir="rtl">`)
- Web app manifest with maskable icon, standalone display, portrait orientation
- Back navigation on every non-root screen (Android back-button parity)
