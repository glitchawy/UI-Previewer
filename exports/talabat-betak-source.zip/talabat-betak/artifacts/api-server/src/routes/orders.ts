import { Router } from "express";
import type { Response } from "express";
import { and, asc, desc, eq, gt, inArray, lte, sql } from "drizzle-orm";
import {
  branchesTable,
  cartItemsTable,
  db,
  driverProfilesTable,
  deliveryPricingTiersTable,
  orderAddonsTable,
  orderItemsTable,
  orderStatusEventsTable,
  ordersTable,
  notificationsTable,
  paymentSessionsTable,
  productAddonsTable,
  productsTable,
  productVariantsTable,
  refundRequestsTable,
  restaurantsTable,
  usersTable,
} from "@workspace/db";
import {
  GetCustomerOrderParams,
  GetCustomerOrderResponse,
  GetOrderDriverLocationParams,
  GetOrderDriverLocationResponse,
  ListCustomerOrdersResponse,
  PlaceOrderBody,
  PlaceOrderResponse,
} from "@workspace/api-zod";
import { getCustomer } from "./cart";
import {
  createPaymentSession,
  getPaymobCallbackUrls,
  getPaymobIntegrationIds,
  isPaymobCheckoutAvailable,
  isDefinitivePaymobCreationError,
  PaymobConfigurationError,
  PaymobRequestError,
} from "../lib/paymob";
import { cancelPendingPaymentSession, expireLockedPaymentSession } from "../lib/payment-session-lifecycle";
import { debitWallet, fromCents, toCents } from "../lib/wallet-ledger";
import { evaluateRestaurantAcceptance } from "../lib/restaurant-acceptance";

const router = Router();
export const DELIVERY_FEE_PER_RESTAURANT = 25;
const PAYMENT_SESSION_TTL_MS = 60 * 60 * 1000;

function orderCode(id: number) {
  return `TB-${String(id).padStart(6, "0")}`;
}

function distanceKm(aLat: number, aLng: number, bLat: number, bLng: number) {
  const rad = (n: number) => n * Math.PI / 180;
  const dLat = rad(bLat - aLat), dLng = rad(bLng - aLng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(aLat)) * Math.cos(rad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

type CheckoutAttachment =
  | { state: "ready"; paymentUrl: string }
  | { state: "creating" }
  | { state: "reconciling" }
  | { state: "closed" };

async function attachPaymobCheckout(
  sessionId: number,
  customer: NonNullable<Awaited<ReturnType<typeof getCustomer>>>,
  address: string,
): Promise<CheckoutAttachment> {
  const claim = await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${sessionId})`);
    const [session] = await tx.select().from(paymentSessionsTable)
      .where(and(eq(paymentSessionsTable.id, sessionId), eq(paymentSessionsTable.customerId, customer.id)))
      .limit(1);
    if (!session || session.status !== "pending") return { state: "closed" as const };
    if (await expireLockedPaymentSession(tx, session)) return { state: "closed" as const };
    if (session.paymentUrl) return { state: "ready" as const, paymentUrl: session.paymentUrl };
    if (session.checkoutCreationStatus === "creating") return { state: "creating" as const };
    if (session.checkoutCreationStatus === "provider_created") return { state: "reconciling" as const };
    await tx.update(paymentSessionsTable).set({
      checkoutCreationStatus: "creating",
      checkoutCreationStartedAt: new Date(),
    })
      .where(eq(paymentSessionsTable.id, session.id));
    return { state: "claimed" as const, session };
  });
  if (claim.state !== "claimed") return claim;

  const nameParts = (customer.name?.trim() || "Customer").split(/\s+/);
  const callbackUrls = getPaymobCallbackUrls(claim.session.id);
  const providerSession = await createPaymentSession({
    reference: claim.session.reference,
    amount: Number(claim.session.amount),
    billing: {
      firstName: nameParts[0] || "Customer",
      lastName: nameParts.slice(1).join(" ") || "Talabat Betak",
      phoneNumber: customer.phone,
      address,
    },
    notificationUrl: callbackUrls.notificationUrl,
    redirectUrl: callbackUrls.redirectUrl,
  });
  return db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${claim.session.id})`);
    const [lockedSession] = await tx.select().from(paymentSessionsTable)
      .where(eq(paymentSessionsTable.id, claim.session.id))
      .limit(1);
    if (!lockedSession || lockedSession.status !== "pending") return { state: "closed" as const };
    if (await expireLockedPaymentSession(tx, lockedSession)) return { state: "closed" as const };
    if (lockedSession.paymentUrl) return { state: "ready" as const, paymentUrl: lockedSession.paymentUrl };
    await tx.update(paymentSessionsTable).set({
      paymobOrderId: providerSession.providerOrderId,
      paymentUrl: providerSession.paymentUrl,
      checkoutCreationStatus: "ready",
      checkoutCreationStartedAt: null,
    }).where(eq(paymentSessionsTable.id, lockedSession.id));
    return { state: "ready" as const, paymentUrl: providerSession.paymentUrl };
  });
}

async function releasePaymentSession(sessionId: number, reason: string) {
  await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${sessionId})`);
    const [session] = await tx.select().from(paymentSessionsTable)
      .where(eq(paymentSessionsTable.id, sessionId))
      .limit(1);
    if (session) await cancelPendingPaymentSession(tx, session, reason);
  });
}

router.post("/orders", async (req, res: Response): Promise<void> => {
  const customer = await getCustomer(req);
  if (!customer) { res.status(401).json({ error: "غير مصرح" }); return; }
  const parsedBody = PlaceOrderBody.safeParse(req.body);
  if (!parsedBody.success) { res.status(400).json({ error: "بيانات الطلب غير صحيحة" }); return; }
  const paymentMethod = parsedBody.data.paymentMethod ?? "cash";
  const requestedWalletCents = toCents(parsedBody.data.useWalletAmount ?? 0);
  const rawNotes = parsedBody.data.notes?.trim() ?? "";
  if (!customer.addressText || customer.lat === null || customer.lng === null) {
    res.status(400).json({ error: "أضف عنوان التوصيل أولاً" }); return;
  }
  const deliveryAddressText = customer.addressText;
  const deliveryLat = customer.lat;
  const deliveryLng = customer.lng;
  let created: {
    orders: {
      id: number;
      restaurantId: number;
      restaurantName: string;
      total: number;
      walletAmountUsed: number;
      externalAmountDue: number;
    }[];
    paymentSessionId: number | null;
    paymentUrl: string | null;
  };
  try {
    created = await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${customer.id})`);
    const [lockedCustomer] = await tx.select({ walletBalance: usersTable.walletBalance })
      .from(usersTable).where(eq(usersTable.id, customer.id)).limit(1);
    if (!lockedCustomer) throw new Error("CUSTOMER_NOT_FOUND");
    // Acceptance is checked before any durable checkout work (including payment
    // expiry repair), so a closed restaurant rejection has no side effects.
    const acceptanceCart = await tx.select().from(cartItemsTable)
      .where(eq(cartItemsTable.userId, customer.id));
    if (!acceptanceCart.length) throw new Error("EMPTY_CART");
    const acceptanceRestaurantIds = [...new Set(acceptanceCart.map((item) => item.restaurantId))];
    const acceptanceRestaurants = await tx.select().from(restaurantsTable)
      .where(inArray(restaurantsTable.id, acceptanceRestaurantIds))
      .for("update");
    const acceptanceBranches = await tx.select().from(branchesTable)
      .where(inArray(branchesTable.restaurantId, acceptanceRestaurantIds))
      .for("update");
    if (acceptanceRestaurantIds.some((restaurantId) => {
      const restaurant = acceptanceRestaurants.find((candidate) => candidate.id === restaurantId);
      return !restaurant || !evaluateRestaurantAcceptance(
        restaurant,
        acceptanceBranches.filter((branch) => branch.restaurantId === restaurantId),
      ).acceptingOrders;
    })) {
      throw new Error("RESTAURANT_NOT_ACCEPTING");
    }
    const now = new Date();
    const expiredSessions = await tx.select().from(paymentSessionsTable).where(and(
      eq(paymentSessionsTable.customerId, customer.id),
      eq(paymentSessionsTable.status, "pending"),
      lte(paymentSessionsTable.expiresAt, now),
    ));
    for (const expiredSession of expiredSessions) await expireLockedPaymentSession(tx, expiredSession, now);
    const [activePayment] = await tx.select().from(paymentSessionsTable)
      .where(and(
        eq(paymentSessionsTable.customerId, customer.id),
        eq(paymentSessionsTable.status, "pending"),
        gt(paymentSessionsTable.expiresAt, now),
      ))
      .limit(1);
    if (activePayment) {
      if (paymentMethod !== "card") throw new Error("PAYMENT_PENDING");
      const activeOrders = await tx.select({
        id: ordersTable.id,
        restaurantId: ordersTable.restaurantId,
        restaurantName: ordersTable.restaurantName,
        total: ordersTable.total,
        walletAmountUsed: ordersTable.walletAmountUsed,
        externalAmountDue: ordersTable.externalAmountDue,
      }).from(ordersTable).where(eq(ordersTable.paymentSessionId, activePayment.id));
      return {
        orders: activeOrders.map((order) => ({
          ...order,
          total: Number(order.total),
          walletAmountUsed: Number(order.walletAmountUsed),
          externalAmountDue: Number(order.externalAmountDue),
        })),
        paymentSessionId: activePayment.id,
        paymentUrl: activePayment.paymentUrl,
      };
    }
    const cartItems = await tx.select().from(cartItemsTable).where(eq(cartItemsTable.userId, customer.id));
    if (!cartItems.length) throw new Error("EMPTY_CART");

    const restaurantIds = [...new Set(cartItems.map((item) => item.restaurantId))];
    const productIds = [...new Set(cartItems.map((item) => item.productId))];
    const addonIds = [...new Set(cartItems.flatMap((item) => item.addonIds))];
    // node-postgres serializes transaction queries on one client. Keep these
    // reads sequential to avoid overlapping client.query() calls.
    const restaurants = await tx.select().from(restaurantsTable).where(inArray(restaurantsTable.id, restaurantIds));
    const products = await tx.select().from(productsTable).where(inArray(productsTable.id, productIds)).for("update");
    const variants = await tx.select().from(productVariantsTable).where(inArray(productVariantsTable.productId, productIds));
    const addons = addonIds.length
      ? await tx.select().from(productAddonsTable).where(inArray(productAddonsTable.id, addonIds))
      : [];
    const branches = await tx.select().from(branchesTable).where(inArray(branchesTable.restaurantId, restaurantIds));
    const pricingTiers = await tx.select().from(deliveryPricingTiersTable)
      .where(eq(deliveryPricingTiersTable.isActive, true))
      .orderBy(deliveryPricingTiersTable.fromKm);
    const restaurantMap = new Map(restaurants.map((row) => [row.id, row]));
    const productMap = new Map(products.map((row) => [row.id, row]));
    const variantMap = new Map(variants.map((row) => [row.id, row]));
    const addonMap = new Map(addons.map((row) => [row.id, row]));
    const branchMap = new Map<number, typeof branches[number]>();
    const restaurantsWithBranches = new Set(branches.map((branch) => branch.restaurantId));
    for (const branch of branches) if (branch.isOpen && !branchMap.has(branch.restaurantId)) branchMap.set(branch.restaurantId, branch);
    const deliveryFees = new Map<number, number>();
    for (const restaurantId of restaurantIds) {
      const branch = branchMap.get(restaurantId);
      const restaurant = restaurantMap.get(restaurantId);
      // Legacy restaurants may legitimately have no branch rows. The public
      // restaurant API treats those restaurants as operational, so checkout
      // must use their canonical restaurant coordinates too. If branch rows do
      // exist, however, all of them being closed still means unavailable.
      if (!restaurant || (!branch && restaurantsWithBranches.has(restaurantId))) {
        throw new Error("UNAVAILABLE_ITEM");
      }
      if (!pricingTiers.length) {
        deliveryFees.set(restaurantId, DELIVERY_FEE_PER_RESTAURANT);
        continue;
      }
      const originLat = branch?.lat ?? restaurant.lat;
      const originLng = branch?.lng ?? restaurant.lng;
      if (originLat === null || originLng === null) throw new Error("DELIVERY_UNAVAILABLE");
      const distance = distanceKm(originLat, originLng, deliveryLat, deliveryLng);
      const tier = pricingTiers.find((candidate) => distance >= Number(candidate.fromKm) && distance < Number(candidate.toKm));
      if (!tier) throw new Error("DELIVERY_UNAVAILABLE");
      deliveryFees.set(restaurantId, Number(tier.price));
    }

    const validLines = cartItems.map((item) => {
      const restaurant = restaurantMap.get(item.restaurantId);
      const product = productMap.get(item.productId);
      const variant = item.variantId === null ? null : variantMap.get(item.variantId);
      const productHasVariants = variants.some((candidate) => candidate.productId === item.productId);
      const selectedAddons = item.addonIds.map((id) => addonMap.get(id));
      if (!restaurant || restaurant.status !== "ACTIVE" || !product || !product.isAvailable ||
        product.restaurantId !== item.restaurantId || (item.variantId === null && productHasVariants) ||
        (item.variantId !== null && (!variant || !variant.isAvailable || variant.productId !== item.productId)) ||
        selectedAddons.some((addon) => !addon || !addon.isAvailable || addon.productId !== item.productId)) {
        throw new Error("UNAVAILABLE_ITEM");
      }
      const addonsForLine = selectedAddons as NonNullable<(typeof selectedAddons)[number]>[];
      const addonPrice = addonsForLine.reduce((sum, addon) => sum + Number(addon.price), 0);
      const unitPrice = Number(product.basePrice) + (variant ? Number(variant.priceDelta) : 0) + addonPrice;
      return { cartItem: item, restaurant, product, variant, addons: addonsForLine, addonPrice, unitPrice, lineTotal: unitPrice * item.quantity };
    });

    const totalCartCents = restaurantIds.reduce((sum, restaurantId) => {
      const lines = validLines.filter((line) => line.cartItem.restaurantId === restaurantId);
      return sum + toCents(lines.reduce((lineSum, line) => lineSum + line.lineTotal, 0) + deliveryFees.get(restaurantId)!);
    }, 0);
    let remainingWalletCents = Math.min(
      requestedWalletCents,
      toCents(lockedCustomer.walletBalance),
      totalCartCents,
    );
    if (
      paymentMethod === "card" &&
      totalCartCents - remainingWalletCents > 0 &&
      !isPaymobCheckoutAvailable()
    ) {
      throw new Error("PAYMOB_UNAVAILABLE");
    }
    const address = `${deliveryAddressText}${customer.addressDetails ? `، ${customer.addressDetails}` : ""}`;
    const results: {
      id: number;
      restaurantId: number;
      restaurantName: string;
      total: number;
      walletAmountUsed: number;
      externalAmountDue: number;
    }[] = [];
    for (const restaurantId of restaurantIds) {
      const restaurant = restaurantMap.get(restaurantId)!;
      const branch = branchMap.get(restaurantId);
      if (!branch && restaurantsWithBranches.has(restaurantId)) throw new Error("UNAVAILABLE_ITEM");
      const lines = validLines.filter((line) => line.cartItem.restaurantId === restaurantId);
      const subtotal = lines.reduce((sum, line) => sum + line.lineTotal, 0);
      const deliveryFee = deliveryFees.get(restaurantId)!;
      const total = subtotal + deliveryFee;
      const totalCents = toCents(total);
      const walletAmountCents = Math.min(remainingWalletCents, totalCents);
      const externalAmountCents = totalCents - walletAmountCents;
      remainingWalletCents -= walletAmountCents;
      const [order] = await tx.insert(ordersTable).values({
        customerId: customer.id,
        restaurantId,
        restaurantName: restaurant.name,
        branchId: branch?.id ?? null,
        branchName: branch?.name ?? null,
        status: "pending",
        paymentMethod,
        paymentStatus: externalAmountCents === 0 ? "paid" : "pending",
        deliveryAddressText: address,
        deliveryLat,
        deliveryLng,
        deliveryFee: deliveryFee.toFixed(2),
        subtotal: subtotal.toFixed(2),
        total: total.toFixed(2),
        walletAmountUsed: fromCents(walletAmountCents),
        externalAmountDue: fromCents(externalAmountCents),
        notes: rawNotes || null,
      }).returning({ id: ordersTable.id });
      await tx.insert(orderStatusEventsTable).values({ orderId: order.id, status: "pending" });
      await tx.insert(notificationsTable).values({
        userId: customer.id,
        eventType: "ORDER_PLACED",
        title: "تم استلام طلبك",
        body: `استلمنا طلبك ${orderCode(order.id)} من ${restaurant.name}`,
        entityType: "order",
        entityId: order.id,
        deduplicationKey: `order:${order.id}:pending`,
      }).onConflictDoNothing();
      for (const line of lines) {
        const [orderItem] = await tx.insert(orderItemsTable).values({
          orderId: order.id,
          productId: line.product.id,
          productName: line.product.name,
          variantId: line.variant?.id ?? null,
          variantName: line.variant?.name ?? null,
          quantity: line.cartItem.quantity,
          unitPrice: line.unitPrice.toFixed(2),
          addonIds: line.cartItem.addonIds,
          addonPrice: line.addonPrice.toFixed(2),
          lineTotal: line.lineTotal.toFixed(2),
        }).returning({ id: orderItemsTable.id });
        if (line.addons.length) {
          await tx.insert(orderAddonsTable).values(line.addons.map((addon) => ({
            orderItemId: orderItem.id, addonId: addon.id, name: addon.name, price: addon.price,
          })));
        }
      }
      if (walletAmountCents > 0) {
        await debitWallet(tx, {
          userId: customer.id,
          amountCents: walletAmountCents,
          description: `دفع طلب ${orderCode(order.id)} من المحفظة`,
          referenceType: "order_payment",
          referenceId: order.id,
        });
      }
      results.push({
        id: order.id,
        restaurantId,
        restaurantName: restaurant.name,
        total,
        walletAmountUsed: walletAmountCents / 100,
        externalAmountDue: externalAmountCents / 100,
      });
    }

    let paymentSessionId: number | null = null;
    let paymentUrl: string | null = null;
    const externalOrders = results.filter((order) => order.externalAmountDue > 0);
    if (paymentMethod === "card" && externalOrders.length) {
      const cardIntegrationIds = getPaymobIntegrationIds();
      getPaymobCallbackUrls(0);
      const reference = `TBP-${crypto.randomUUID()}`;
      const amount = externalOrders.reduce((sum, order) => sum + order.externalAmountDue, 0);
      const [session] = await tx.insert(paymentSessionsTable).values({
        customerId: customer.id,
        reference,
        amount: amount.toFixed(2),
        expiresAt: new Date(now.getTime() + PAYMENT_SESSION_TTL_MS),
        paymobIntegrationId: cardIntegrationIds[0],
        paymobIntegrationIds: cardIntegrationIds,
      }).returning({ id: paymentSessionsTable.id });
      await tx.update(ordersTable).set({ paymentSessionId: session.id })
        .where(inArray(ordersTable.id, externalOrders.map((order) => order.id)));
      await tx.update(cartItemsTable).set({ paymentSessionId: session.id })
        .where(and(
          eq(cartItemsTable.userId, customer.id),
          inArray(cartItemsTable.restaurantId, externalOrders.map((order) => order.restaurantId)),
        ));
      const fullyWalletPaidRestaurantIds = results
        .filter((order) => order.externalAmountDue === 0)
        .map((order) => order.restaurantId);
      if (fullyWalletPaidRestaurantIds.length) {
        await tx.delete(cartItemsTable).where(and(
          eq(cartItemsTable.userId, customer.id),
          inArray(cartItemsTable.restaurantId, fullyWalletPaidRestaurantIds),
        ));
      }
      paymentSessionId = session.id;
    }
    if (paymentMethod === "cash" || (paymentMethod === "card" && !externalOrders.length)) {
      await tx.delete(cartItemsTable).where(eq(cartItemsTable.userId, customer.id));
    }
    return { orders: results, paymentSessionId, paymentUrl };
  });
  } catch (error) {
    if (error instanceof Error && error.message === "EMPTY_CART") {
      res.status(400).json({ error: "السلة فارغة" });
      return;
    }
    if (error instanceof Error && error.message === "UNAVAILABLE_ITEM") {
      res.status(409).json({ error: "أحد عناصر السلة لم يعد متاحاً. راجع السلة وحاول مرة أخرى." });
      return;
    }
    if (error instanceof Error && error.message === "RESTAURANT_NOT_ACCEPTING") {
      res.status(409).json({
        code: "RESTAURANT_NOT_ACCEPTING",
        error: "المطعم مغلق أو لا يستقبل الطلبات حالياً. احتفظنا بعناصر سلتك لتجرب مرة أخرى لاحقاً.",
      });
      return;
    }
    if (error instanceof Error && error.message === "DELIVERY_UNAVAILABLE") {
      res.status(409).json({ error: "عنوانك خارج شرائح التوصيل النشطة حالياً" });
      return;
    }
    if (error instanceof Error && error.message === "PAYMENT_PENDING") {
      res.status(409).json({ error: "لديك عملية دفع أونلاين بانتظار التأكيد. أكملها أو انتظر انتهاءها قبل إنشاء طلب جديد." });
      return;
    }
    if (error instanceof Error && error.message === "PAYMOB_UNAVAILABLE") {
      res.status(503).json({
        code: "PAYMOB_UNAVAILABLE",
        error: "الدفع أونلاين غير متاح حالياً. اختر الدفع كاش أو استخدم رصيد المحفظة بالكامل.",
      });
      return;
    }
    if (error instanceof PaymobConfigurationError) {
      res.status(503).json({ error: "الدفع أونلاين غير مُجهز حالياً. اختر الدفع كاش أو حاول لاحقاً." });
      return;
    }
    if (error instanceof PaymobRequestError) {
      res.status(502).json({ error: "تعذر بدء جلسة الدفع أونلاين. لم يتم إنشاء الطلب، حاول مرة أخرى." });
      return;
    }
    throw error;
  }
  if (paymentMethod === "card" && created.paymentSessionId) {
    const address = `${deliveryAddressText}${customer.addressDetails ? `، ${customer.addressDetails}` : ""}`;
    try {
      const checkout = await attachPaymobCheckout(created.paymentSessionId, customer, address);
      if (checkout.state === "creating") {
        res.status(409).json({ error: "يتم تجهيز رابط الدفع بأمان. لا تنشئ عملية دفع جديدة؛ افتح طلباتك بعد لحظات للتحقق." });
        return;
      }
      if (checkout.state === "reconciling") {
        res.status(409).json({ error: "نؤكد حالة الدفع مع المزود الآن. لا تنشئ عملية دفع جديدة؛ افتح طلباتك أو انتظر انتهاء الجلسة." });
        return;
      }
      if (checkout.state === "closed") {
        res.status(409).json({ error: "انتهت جلسة الدفع. يمكنك إعادة المحاولة من السلة." });
        return;
      }
      created.paymentUrl = checkout.paymentUrl;
    } catch (error) {
      if (isDefinitivePaymobCreationError(error)) {
        await releasePaymentSession(created.paymentSessionId, "Paymob rejected checkout creation");
        res.status(502).json({ error: "رفض مزود الدفع إنشاء الجلسة. ألغينا الطلب المؤقت وأعدنا فتح السلة للمحاولة." });
        return;
      }
      if (error instanceof PaymobConfigurationError) {
        res.status(503).json({ error: "الدفع أونلاين غير مُجهز حالياً. اختر الدفع كاش أو حاول لاحقاً." });
        return;
      }
      if (error instanceof PaymobRequestError) {
        res.status(502).json({ error: "تعذر تأكيد رابط الدفع حالياً. احتفظنا بطلبك وسلتك بأمان؛ افتح طلباتك بعد لحظات للتحقق قبل إعادة المحاولة." });
        return;
      }
      res.status(502).json({ error: "تعذر تأكيد رابط الدفع حالياً. احتفظنا بطلبك وسلتك بأمان؛ أعد المحاولة بعد دقيقتين." });
      return;
    }
  }
  res.status(201).json(PlaceOrderResponse.parse({
    orders: created.orders.map((order) => ({
      id: order.id,
      restaurantName: order.restaurantName,
      total: order.total,
      walletAmountUsed: order.walletAmountUsed,
      externalAmountDue: order.externalAmountDue,
      code: orderCode(order.id),
      estimateMinutes: "30-40",
    })),
    paymentSessionId: created.paymentSessionId,
    paymentUrl: created.paymentUrl,
  }));
});

router.get("/orders", async (req, res: Response): Promise<void> => {
  const customer = await getCustomer(req);
  if (!customer) { res.status(401).json({ error: "غير مصرح" }); return; }
  const rows = await db.select().from(ordersTable)
    .where(eq(ordersTable.customerId, customer.id)).orderBy(desc(ordersTable.createdAt));
  res.json(ListCustomerOrdersResponse.parse(rows.map((order) => ({
    id: order.id, code: orderCode(order.id), restaurantName: order.restaurantName, status: order.status,
    paymentMethod: order.paymentMethod, paymentStatus: order.paymentStatus,
    subtotal: Number(order.subtotal), deliveryFee: Number(order.deliveryFee), total: Number(order.total),
    createdAt: order.createdAt,
  }))));
});

router.get("/orders/:id", async (req, res: Response): Promise<void> => {
  const customer = await getCustomer(req);
  if (!customer) { res.status(401).json({ error: "غير مصرح" }); return; }
  const parsedParams = GetCustomerOrderParams.safeParse(req.params);
  if (!parsedParams.success || !Number.isInteger(parsedParams.data.id)) {
    res.status(400).json({ error: "رقم الطلب غير صحيح" }); return;
  }
  const id = parsedParams.data.id;
  const [order] = await db.select().from(ordersTable)
    .where(and(eq(ordersTable.id, id), eq(ordersTable.customerId, customer.id))).limit(1);
  if (!order) { res.status(404).json({ error: "الطلب غير موجود" }); return; }
  const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, id));
  const itemIds = items.map((item) => item.id);
  const addons = itemIds.length ? await db.select().from(orderAddonsTable).where(inArray(orderAddonsTable.orderItemId, itemIds)) : [];
  const events = await db.select().from(orderStatusEventsTable)
    .where(eq(orderStatusEventsTable.orderId, id))
    .orderBy(asc(orderStatusEventsTable.createdAt), asc(orderStatusEventsTable.id));
  const [refundRequest] = await db.select({ status: refundRequestsTable.status })
    .from(refundRequestsTable)
    .where(and(
      eq(refundRequestsTable.orderId, id),
      eq(refundRequestsTable.source, "customer_request"),
    ))
    .limit(1);
  const statusLabels: Record<typeof order.status, string> = {
    pending: "تم استلام طلبك", confirmed: "المطعم أكد الطلب", preparing: "جاري تحضير الطلب",
    ready: "الطلب جاهز", picked_up: "الطلب خرج للتوصيل", delivered: "تم توصيل الطلب", cancelled: "تم إلغاء الطلب",
  };
  const timeline = events.length ? events : [{ status: order.status, createdAt: order.createdAt }];
  const [driver] = order.driverProfileId
    ? await db.select({
        name: driverProfilesTable.fullName,
        phone: usersTable.phone,
        lat: driverProfilesTable.currentLat,
        lng: driverProfilesTable.currentLng,
        updatedAt: driverProfilesTable.locationUpdatedAt,
      }).from(driverProfilesTable)
        .innerJoin(usersTable, eq(usersTable.id, driverProfilesTable.userId))
        .where(eq(driverProfilesTable.id, order.driverProfileId))
        .limit(1)
    : [];
  res.json(GetCustomerOrderResponse.parse({
    id: order.id, code: orderCode(order.id), restaurantName: order.restaurantName,
    status: order.status, paymentMethod: order.paymentMethod, paymentStatus: order.paymentStatus,
    deliveryAddressText: order.deliveryAddressText, deliveryLat: order.deliveryLat, deliveryLng: order.deliveryLng,
    walletAmountUsed: Number(order.walletAmountUsed),
    externalAmountDue: Number(order.externalAmountDue),
    canCancel: order.status === "pending" || order.status === "confirmed",
    canRequestRefund: order.status === "delivered" && !refundRequest,
    refundRequestStatus: refundRequest?.status ?? null,
    driverName: driver?.name ?? null, driverPhone: driver?.phone ?? null,
    driverLat: order.status === "picked_up" ? driver?.lat ?? null : null,
    driverLng: order.status === "picked_up" ? driver?.lng ?? null : null,
    driverLocationUpdatedAt: order.status === "picked_up" ? driver?.updatedAt ?? null : null,
    subtotal: Number(order.subtotal),
    deliveryFee: Number(order.deliveryFee), total: Number(order.total), notes: order.notes,
    createdAt: order.createdAt,
    timeline: timeline.map((event) => ({ status: event.status, at: event.createdAt, label: statusLabels[event.status] })),
    items: items.map((item) => ({
      id: item.id, productId: item.productId, name: item.productName, variantName: item.variantName,
      quantity: item.quantity, unitPrice: Number(item.unitPrice), lineTotal: Number(item.lineTotal),
      addons: addons.filter((addon) => addon.orderItemId === item.id).map((addon) => ({ name: addon.name, price: Number(addon.price) })),
    })),
  }));
});

router.get("/orders/:id/driver-location", async (req, res: Response): Promise<void> => {
  const customer = await getCustomer(req);
  if (!customer) { res.status(401).json({ error: "غير مصرح" }); return; }
  const parsedParams = GetOrderDriverLocationParams.safeParse(req.params);
  if (!parsedParams.success || !Number.isInteger(parsedParams.data.id)) {
    res.status(400).json({ error: "رقم الطلب غير صحيح" }); return;
  }
  const [order] = await db.select({
    driverProfileId: ordersTable.driverProfileId,
    status: ordersTable.status,
  }).from(ordersTable)
    .where(and(eq(ordersTable.id, parsedParams.data.id), eq(ordersTable.customerId, customer.id))).limit(1);
  if (!order) { res.status(404).json({ error: "الطلب غير موجود" }); return; }
  const [driver] = order.driverProfileId && order.status === "picked_up"
    ? await db.select({
        lat: driverProfilesTable.currentLat,
        lng: driverProfilesTable.currentLng,
        updatedAt: driverProfilesTable.locationUpdatedAt,
      }).from(driverProfilesTable).where(eq(driverProfilesTable.id, order.driverProfileId)).limit(1)
    : [];
  res.json(GetOrderDriverLocationResponse.parse({
    lat: driver?.lat ?? null,
    lng: driver?.lng ?? null,
    updatedAt: driver?.updatedAt ?? null,
  }));
});

export default router;